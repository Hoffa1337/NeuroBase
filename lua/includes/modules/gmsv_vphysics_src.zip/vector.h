

/*-------------------------------------
	PushVector
-------------------------------------*/
inline void PushVector( lua_State* L, Vector& vec )
{

	// horrible horrible
	ILuaObject* CreateVectorFunction = Lua()->GetGlobal( "Vector" );

	// call
	Lua()->Push( CreateVectorFunction );
	Lua()->Push( vec.x );
	Lua()->Push( vec.y );
	Lua()->Push( vec.z );
	Lua()->Call( 3, 1 );

	// fetch the returned data
	ILuaObject* Returned = Lua()->GetReturn( 0 );
	if( Returned )
	{

		// push
		Lua()->Push( Returned );

	}

	// cleanup
	CreateVectorFunction->UnReference();

}

/*-------------------------------------
	GetVector
-------------------------------------*/
inline Vector* GetVector( lua_State* L, int stackpos )
{

	return (Vector*)Lua()->GetUserData( stackpos );
	
}

